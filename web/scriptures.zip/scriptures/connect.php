<?php

$dbuser = 'dzuyuopgjyjdiq';
$host = 'ec2-23-23-227-188.compute-1.amazonaws.com';
$dbname = 'd97gn4ualml6qq';
$dbpass = '99556258ef88831cdabae4b53ba822c7c3f87ed453fffd81252d8c71d86a1bee';
$db = new PDO("pgsql:dbname=$dbname;host=$host", $dbuser, $dbpass);

?>